function AdminDashboard() {
    return (
        <div>
            <h1>Bienvenido al Panel de Administración</h1>
            <p>Desde aquí puedes gestionar empresas, clientes y administradores.</p>
        </div>
    );
}

export default AdminDashboard;
