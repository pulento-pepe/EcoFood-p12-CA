export default function ClienteDashboard() {
    return <h2>Bienvenido cliente</h2>;
    }
    