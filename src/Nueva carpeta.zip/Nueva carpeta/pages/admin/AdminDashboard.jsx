export default function AdminDashboard() {
    return <h2>Panel del Administrador</h2>;
    }
    