export default function AdminProductos() {
    return <h2>Panel del productos</h2>;
    }